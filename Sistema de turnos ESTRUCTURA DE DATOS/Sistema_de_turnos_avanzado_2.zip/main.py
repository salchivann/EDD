"""
Punto de entrada del Sistema de Gestión de Atención al Cliente y
Turnos Inteligentes.

Requiere: customtkinter (pip install customtkinter)
Ejecutar con: python main.py
"""

from interfaz import *
